module.exports = {
    database:{
        // host: 'db-mysql-0001.mysql.database.azure.com',
        // user: 'db_mysql_0001@db-mysql-0001',
        // password: 'Surco123.',
        // database: 'database_links'
        host: '157.90.70.110',
        database: 'tuservic_database_links',
        user: 'tuservic_sergio',
        password: 'MF]0IbRP&5q{',
        port: '3306'
    }
}